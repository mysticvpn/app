if fisrt run


Run codeph.exe
Type Mystic to the textbox
click align button
then go to desktop open the generated Mystic folder
then run MysticVpn.exe